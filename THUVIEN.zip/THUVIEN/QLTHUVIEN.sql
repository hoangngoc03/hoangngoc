﻿drop database QLThuViens
create database QLThuViens
go
use QLThuViens
go

-----

create table DOCGIA
(
	MaDocGia int Identity(1,1),
	HoTen nchar(30),
	GioiTinh nchar(5),
	NamSinh date,
	PRIMARY KEY (MaDocGia),
)
go
insert into DOCGIA (HoTen,GioiTinh,NamSinh) values (N'Lê Thị Hoàng Ngọc',N'Nữ','2000')
insert into DOCGIA (HoTen,GioiTinh,NamSinh) values (N'Nguyễn Lê Phúc Hậu',N'Nữ','1979')
insert into DOCGIA (HoTen,GioiTinh,NamSinh) values (N'Phạm Huỳnh Tín','Nam','2000')
insert into DOCGIA (HoTen,GioiTinh,NamSinh) values (N'Lư Hưng Vương',N'Nam','2000')
insert into DOCGIA (HoTen,GioiTinh,NamSinh) values (N'Lý Hồng Loan',N'Nữ','1999')
insert into DOCGIA (HoTen,GioiTinh,NamSinh) values (N'Lê Hồng Phát',N'Nữ','1994')
select* from DOCGIA
drop table DOCGIA
go
create table NHANVIEN
(
	MaNV int Identity(1,1),
	HoTen nchar(30),
	TenDangNhap nchar(30),
	NamSinh date,
	DiaChi nchar(100),
	PRIMARY KEY (MaNV),
)
go
insert into NHANVIEN (HoTen,TenDangNhap,NamSinh,DiaChi) values (N'Lê Thị Hoàng Ngọc', N'hoangngoc','2000',N'Phú Quốc Kiên Giang')
insert into NHANVIEN (HoTen,TenDangNhap,NamSinh,DiaChi) values (N'Nguyễn Lê Phúc Hậu', N'phuchau','1998',N'Phú Quốc Kiên Giang')
insert into NHANVIEN (HoTen,TenDangNhap,NamSinh,DiaChi) values (N'Phạm Huỳnh Tín', N'huynhtin','1999',N'Phú Quốc Kiên Giang')
insert into NHANVIEN (HoTen,TenDangNhap,NamSinh,DiaChi) values (N'Lư Hưng Vương', N'hungvuong','2001',N'Bà Rịa Tây Ninh')
insert into NHANVIEN (HoTen,TenDangNhap,NamSinh,DiaChi) values (N'Hoàn Văn Thành', N'hoanthanh','2000',N'Vũng Tàu Hà Nội')
insert into NHANVIEN (HoTen,TenDangNhap,NamSinh,DiaChi) values (N'Bùi Thẩm Đoàn', N'doanbui','2002',N'Bến Tre Phú Yên')
select *from NHANVIEN
set identity_insert NHANVIEN on;
go
drop table NHANVIEN
go


create table SACH
(
	MaSach int Identity(1,1),
	TenSach nchar(50),
	TacGia nchar(30),
	TheLoai nchar(30),
	NhaXuatBan nchar(50),
	GiaSach int,
	SoLuong int,
	PRIMARY KEY (MaSach),
)
go
insert into SACH (TenSach,TacGia,TheLoai,NhaXuatBan,GiaSach,SoLuong) values (N'Thiên Tử',N'Thiên Hương',N'Truyện',N'TP.HCM','150000','50')
insert into SACH (TenSach,TacGia,TheLoai,NhaXuatBan,GiaSach,SoLuong) values (N'Đại số tuyến tính',N'Thiên Hương',N'Truyện',N'TP.HCM','150000','50')
insert into SACH (TenSach,TacGia,TheLoai,NhaXuatBan,GiaSach,SoLuong) values (N'Toán rời rạc',N'Thiên Hương',N'Truyện',N'TP.HCM','150000','50')
insert into SACH (TenSach,TacGia,TheLoai,NhaXuatBan,GiaSach,SoLuong) values (N'MAC',N'Thiên Hương',N'Truyện',N'TP.HCM','150000','50')
insert into SACH (TenSach,TacGia,TheLoai,NhaXuatBan,GiaSach,SoLuong) values (N'Thiên Tử',N'Thiên Hương',N'Truyện',N'TP.HCM','150000','50')
select*from SACH
drop table SACH
go


create table PHIEUMUON
(
	MaPhieu int Identity(1,1),
	MaDocGia int,
	MaNV int,
	MaSach int,
	NgayMuon date,
	NgayPhaiTra date,
	PRIMARY KEY (MaPhieu),
)
go

insert into PHIEUMUON (MaDocGia,MaNV,MaSach,NgayMuon,NgayPhaiTra) values ('1','1','1','2020/10/16','2020/10/18')
insert into PHIEUMUON (MaDocGia,MaNV,MaSach,NgayMuon,NgayPhaiTra) values ('2','2','2','2020/10/16','2020/10/18')
insert into PHIEUMUON (MaDocGia,MaNV,MaSach,NgayMuon,NgayPhaiTra) values ('3','3','3','2020/10/16','2020/10/18')

select *from PHIEUMUON
drop table PHIEUTRA
go
create table PHIEUTRA
(
	MaPhieu int Identity(1,1),
	MaNV int ,
	MaSach int,
	NgayTra date,
	PRIMARY KEY (MaPhieu),
)
go
insert into PHIEUTRA (MaNV,MaSach,NgayTra) values ('1','1','2020-10-23')
insert into PHIEUTRA (MaNV,MaSach,NgayTra) values ('2','2','2020-10-23')
insert into PHIEUTRA (MaNV,MaSach,NgayTra) values ('3','3','2020-10-23')
select*from PHIEUTRA

drop table ACCOUNT
go
create table ACCOUNT
(
	MaAcc int Identity(1,1) ,
	MaNV int,
	TenDangNhap nchar(30),
	MatKhau nchar(30),
	PRIMARY KEY (MaAcc),
	
)
go
insert into ACCOUNT (MaNV,TenDangNhap,MatKhau) values ('1','hoangngoc','123456')
insert into ACCOUNT (MaNV,TenDangNhap,MatKhau) values ('2','phuchau','123456')
insert into ACCOUNT (MaNV,TenDangNhap,MatKhau) values ('3','huynhtin','123456')

SELECT * FROM ACCOUNT 
WHERE TenDangNhap like N'%hai%' and MatKhau like '%2%'

alter table PHIEUMUON add
	constraint FK_PHIEUMUON_NHANVIEN foreign key (MaNV) references NHANVIEN (MaNV),
	constraint FK_PHIEUMUON_SACH foreign key (MaSach) references SACH (MaSach),
	constraint FK_PHIEUMUON_DOCGIA foreign key (MaDocGia) references DOCGIA (MaDocGIa)

alter table PHIEUTRA add
	constraint FK_PHIEUTRA_NHANVIEN foreign key (MaNV) references NHANVIEN (MaNV),
	constraint FK_PHIEUTRA_SACH foreign key (MaSach) references SACH (MaSach)

alter table ACCOUNT add
	constraint FK_ACCOUNT_NHANVIEN foreign key (MaNV) references NHANVIEN (MaNV)











