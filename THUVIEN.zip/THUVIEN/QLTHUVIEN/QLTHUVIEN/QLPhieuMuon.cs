﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLTHUVIEN
{
    public partial class QLPhieuMuon : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=DESKTOP-H9LM095\\SQLEXPRESS;Initial Catalog=QLThuViens;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table3 = new DataTable();

        void Loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "select *from PHIEUMUON";
            adapter.SelectCommand = command;
            table3.Clear();
            adapter.Fill(table3);
            dgvMuon.DataSource = table3;
        }

        public QLPhieuMuon()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void QLPhieuMuon_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            Loaddata();

        }

        private void dgvMuon_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
