﻿using QLTHUVIEN.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLTHUVIEN
{
    public partial class QLPhieuTra : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=DESKTOP-H9LM095\\SQLEXPRESS;Initial Catalog=QLThuViens;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable tablemuon = new DataTable();

        void Loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "select *from PHIEUTRA";
            adapter.SelectCommand = command;
            tablemuon.Clear();
            adapter.Fill(tablemuon);
            dgvTra.DataSource = tablemuon;
        }

        public QLPhieuTra()
        {
            InitializeComponent();
        }

        private void QLPhieuTra_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            Loaddata();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
