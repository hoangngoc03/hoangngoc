﻿using QLTHUVIEN.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLTHUVIEN
{
    public partial class QLSach : Form
    {
        bool c = true;
        public QLSach()
        {
            InitializeComponent();
            setNut(true);
            Load();
        }

        private void Load()
        {
            Models.ModSach tb = new Models.ModSach();
            DataTable dt = tb.docdulieu();
            dgvSach.DataSource = dt;
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
        private void setNut(bool a)
        {
            btnThem.Enabled = a;
            btnSua.Enabled = a;
            btnXoa.Enabled = a;
            btnLuu.Enabled = !a;
            btnKluu.Enabled = !a;
        }
        private void datasach_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMaSach.ReadOnly = true;
            int index = dgvSach.CurrentRow.Index;
            txtMaSach.Text = dgvSach.Rows[index].Cells[0].Value.ToString();
            txtTenSach.Text = dgvSach.Rows[index].Cells[1].Value.ToString();
            txtTacGia.Text = dgvSach.Rows[index].Cells[2].Value.ToString();
            txtTheLoai.Text = dgvSach.Rows[index].Cells[3].Value.ToString();
            txtNXB.Text = dgvSach.Rows[index].Cells[4].Value.ToString();
            txtGiaBan.Text = dgvSach.Rows[index].Cells[5].Value.ToString();
            txtSoLuong.Text = dgvSach.Rows[index].Cells[6].Value.ToString();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            //chọn thêm thì ẩn nut sửa , xoá + xoá hết dữ liệu đang nhập
            setNut(false);
            c = true;
            txtTenSach.Clear();
            txtTacGia.Text = "";
            txtTheLoai.Text = "";
            txtNXB.Text = "";
            txtGiaBan.Text = "";
            txtSoLuong.Text = "";
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (c == true)
            {
                ModSach them = new ModSach();
                string tensach = txtTenSach.Text;
                string tacgia = txtTacGia.Text;
                string theloai = txtTheLoai.Text;
                string nxb = txtNXB.Text;
                int giaban = int.Parse(txtGiaBan.Text);
                int soluong = int.Parse(txtSoLuong.Text);
                bool kq = them.ThemSach(tensach, tacgia, theloai, nxb, giaban, soluong);
                if (kq == true)
                    MessageBox.Show("Thêm thành công!", "Thông báo");
                setNut(true);
                Load();// load lai du lieu vao dgv

            }
            else
            {
                ModSach Sua = new ModSach();
                int masach = int.Parse(txtMaSach.Text);
                string tensach = txtTenSach.Text;
                string tacgia = txtTacGia.Text;
                string theloai = txtTheLoai.Text;
                string nxb = txtNXB.Text;
                int giaban = int.Parse(txtGiaBan.Text);
                int soluong = int.Parse(txtSoLuong.Text);
                bool kq1 = Sua.SuaSach(masach, tensach, tacgia, theloai, nxb, giaban, soluong);
                setNut(true);
                Load();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //sau khi chọn dòng cần xoá bấm xoá thì ẩn nút sửa và thêm
            setNut(false);
            //hiện lên message hỏi có muốn xoá hay không
            if (MessageBox.Show("Bạn Có Muốn Xoá Sách Này", "Cảnh Báo", MessageBoxButtons.OKCancel) == DialogResult.OK) 
            {
                //nếu ok thì thực hiện lệnh xoá theo mã đọc giả
                ModSach Xoa = new ModSach();
                string Ma = txtMaSach.Text;
                bool kq = Xoa.XoaSach(Ma);
                if (kq == true) 
                {
                    MessageBox.Show("Xoá Thành Công!");
                }
                Load();
                setNut(true);
                txtTenSach.Clear();
                txtTacGia.Clear();
                txtTheLoai.Clear();
                txtNXB.Clear();
                txtGiaBan.Clear();
                txtSoLuong.Clear();
            } 
            else
            {
                 // chọn cancel thì bật tất cả nút, xoá dữ liệu trên textbox
                 setNut(true);
                 txtTenSach.Clear();
                 txtTacGia.Clear();
                 txtTheLoai.Clear();
                 txtNXB.Clear();
                 txtGiaBan.Clear();
                 txtSoLuong.Clear();
            }
        }

        private void btnKluu_Click(object sender, EventArgs e)
        {
            setNut(true);
            txtTenSach.Clear();
            txtTacGia.Clear();
            txtTheLoai.Clear();
            txtNXB.Clear();
            txtGiaBan.Clear();
            txtSoLuong.Clear();
            txtMaSach.Clear();
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            setNut(false);
            c = false;
        }

        private void QLSach_Load(object sender, EventArgs e)
        {

        }

        private void QLSach_Load_1(object sender, EventArgs e)
        {

        }

      
    }
}

